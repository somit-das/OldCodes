package com.softgv.cda.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.softgv.cda.entity.Course;

public interface CourseRepository extends JpaRepository<Course, Integer>{

}
