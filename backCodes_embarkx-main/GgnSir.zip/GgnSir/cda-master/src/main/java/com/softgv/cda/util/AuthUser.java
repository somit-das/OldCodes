package com.softgv.cda.util;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthUser {
	public String username;
	private String password;
}
