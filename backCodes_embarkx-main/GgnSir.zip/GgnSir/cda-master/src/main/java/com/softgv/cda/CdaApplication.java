package com.softgv.cda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdaApplication.class, args);
	}

}
