package com.softgv.cda.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.softgv.cda.entity.StudentProfile;

public interface StudentProfileRepository extends JpaRepository<StudentProfile, Integer>{

}
