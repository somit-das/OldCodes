package com.softgv.cda.util;

public enum Role {
	STUDENT, FACULTY, ADMINISTRATOR;
}
