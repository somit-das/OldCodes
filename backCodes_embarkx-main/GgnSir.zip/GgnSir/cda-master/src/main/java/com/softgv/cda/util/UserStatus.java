package com.softgv.cda.util;

public enum UserStatus {
	IN_ACTIVE,ACTIVE,BLOCKED;
}
