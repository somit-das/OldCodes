package com.softgv.cda.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.softgv.cda.entity.FacultyProfile;

public interface FacultyProfileRepository extends JpaRepository<FacultyProfile, Integer> {

}
