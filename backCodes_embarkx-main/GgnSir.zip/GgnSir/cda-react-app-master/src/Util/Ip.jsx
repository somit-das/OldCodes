const Ip = "localhost:8080";

export default Ip;
