import React from "react";

const Dashboard = () => {
  return (
    <div className="min-h-screen flex flex-col items-center ">
      <h1 className="text-4xl font-bold mt-40 text-green-600">Admin Dashboard</h1>
      <h1 className="text-4xl font-bold mt-4 text-green-600">Comming Soon...</h1>
    </div>
  );
};

export default Dashboard;
