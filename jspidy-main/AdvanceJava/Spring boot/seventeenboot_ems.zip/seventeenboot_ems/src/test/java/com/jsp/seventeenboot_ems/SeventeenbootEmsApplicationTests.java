package com.jsp.seventeenboot_ems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeventeenbootEmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
