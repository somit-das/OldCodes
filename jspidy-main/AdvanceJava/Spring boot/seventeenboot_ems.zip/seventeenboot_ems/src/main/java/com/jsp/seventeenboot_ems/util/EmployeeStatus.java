package com.jsp.seventeenboot_ems.util;

public enum EmployeeStatus {
	ACTIVE,IN_ACTIVE
}
