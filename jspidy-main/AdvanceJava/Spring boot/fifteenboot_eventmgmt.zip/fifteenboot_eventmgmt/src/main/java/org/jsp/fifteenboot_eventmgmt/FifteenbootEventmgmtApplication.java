package org.jsp.fifteenboot_eventmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FifteenbootEventmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(FifteenbootEventmgmtApplication.class, args);
	}

}
