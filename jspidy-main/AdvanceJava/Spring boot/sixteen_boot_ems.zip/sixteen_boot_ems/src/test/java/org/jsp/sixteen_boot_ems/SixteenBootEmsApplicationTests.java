package org.jsp.sixteen_boot_ems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SixteenBootEmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
