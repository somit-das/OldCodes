package org.jsp.sixteen_boot_ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SixteenBootEmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SixteenBootEmsApplication.class, args);
	}

}
