import React, { useEffect, useState } from "react";
import "./../style/Book.css";
import { useLocation, useNavigate } from "react-router-dom";

const Books = () => {
  let loc = useLocation()
   let path=loc.pathname.startsWith("/adminportal")
  let [book, setBook] = useState([]);
  useEffect(() => {
    let api = fetch("http://localhost:4000/books");
    let fullapi = api.then(first => {
      return first.json();
    });
    fullapi.then(sec => {
      setBook(sec);
      console.log(book);
    });
  }, [book]);

  //reading a book
  let nav = useNavigate();

  let readbook = id => {
    if (path)
    {
       nav(`/adminportal/readbook/${id}`);
    }
    else {
       nav(`/userportal/readbook/${id}`);
    }
  };

  //deleting a book
  function f1(id, title) {
    let x = window.confirm(`do you want to to delete ${title}`);
    if (x) {
      fetch(`http://localhost:4000/books/${id}`, { method: "DELETE" });
      alert("book deleted ");
    } else {
      alert("not deleted");
    }
  }



  return (
    <div>
      <h1>BOOKS ARE HERE</h1>
      <div className="par">
        {book.map(data => {
          console.log(data);

          return (
            <>
              <div className="ch">
                <br />
                <img src={data.thumbnailUrl} alt="" />
                <h3>{data.title}</h3>
                <h4>book id :{data.id}</h4>
                <br />

                <button
                  onClick={() => {
                    readbook(data.id);
                  }}
                >
                  read book
                </button>
                <br />
                <br />
                {path?(<button
                  onClick={() => {
                    f1(data.id, data.title);
                  }}
                >
                  delete book
                </button>):""}
              </div>
            </>
          );
        })}
      </div>
    </div>
  );
};

export default Books;
