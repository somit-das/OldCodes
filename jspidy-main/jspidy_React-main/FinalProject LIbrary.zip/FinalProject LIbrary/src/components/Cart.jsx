import React, { useEffect, useState } from "react";



const Cart = () => {
  let [cart, setCart] = useState([]);
  useEffect(() => {
    let api = fetch("http://localhost:4000/cart");
    let fullapi = api.then(first => {
      return first.json();
    });
    fullapi.then(sec => {
      setCart(sec);
      console.log(cart);
    });
  }, [cart]);
  console.log(cart);

  //deleting a book  from tyha cart
  function f1(id, title) {
    let x = window.confirm(`do you want to to delete ${title}`);
    if (x) {
      fetch(`http://localhost:4000/cart/${id}`, { method: "DELETE" });
      alert("book deleted ");
    } else {
      alert("not deleted");
    }
  }



  

    
    let empty = Boolean(cart.length);
  return (
    <div>
      <h1>cart books are here</h1>
      <table border={2} rules="all">
        <tr>
          <td>id</td>
          <td>cartid</td>
          <td>title</td>
          <td>authors</td>
          <td>image</td>
          <td>remove</td>
        
        </tr>
        {cart.map(a => {
          return (
            <>
              <tr>
                <td>{a.id}</td>
                <td>{a.cartid}</td>
                <td>{a.carttitle}</td>
                <td>
                  <img src={a.cartimage} alt="" />
                </td>
                <td>{a.cartauthors}</td>
                <td>
                  <button
                    onClick={() => {
                      f1(a.id, a.carttitle);
                    }}
                  >
                    remove{" "}
                  </button>
                </td>
                
              </tr>
            </>
          );
        })}
              {empty ? "" : (
                  <tr>
                      <td colSpan={6}>no books in the cart</td>
                  </tr>
              )}
      </table>
    </div>
  );
};

export default Cart;
