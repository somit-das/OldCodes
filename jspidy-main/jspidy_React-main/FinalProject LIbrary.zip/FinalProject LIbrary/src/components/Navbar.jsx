import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import "./../style/Navbar.css";

const Navbar = () => {
  let loc = useLocation();
  console.log(loc); //loc={pathname:"/presentpath"}
  let path = loc.pathname.startsWith("/adminportal"); //true/false

  return (
    <div>
      {path ? (
        <>
          <ul>
            <li>
              <NavLink to={"/adminportal/"}>HOME</NavLink>{" "}
            </li>
            <li>
              <NavLink to={"/adminportal/about"}>ABOUT</NavLink>
            </li>
            <li>
              <NavLink to={"/adminportal/books"}>BOOKS</NavLink>
            </li>
            <li> 
              <NavLink to={"/adminportal/cart"}>CART</NavLink>
            </li>
            <li>
              <NavLink to={"/adminportal/addbooks"}>ADD BOOKS</NavLink>
            </li>
            
            <li>
              <NavLink to={"/adminportal/users"}>USERS</NavLink>
            </li>
            <li>
              <NavLink to={"/adminportal/adduser"}> ADD USER</NavLink>
            </li>
            <li>
              <NavLink to={"/"}>LOGOUT</NavLink>{" "}
            </li>
          </ul>
        </>
      ) : (
        <>
          <ul>
            <li>
              <NavLink to={"/userportal/"}>HOME</NavLink>
            </li>
            <li>
              <NavLink to={"/userportal/about"}>ABOUT</NavLink>
            </li>
            <li>
              <NavLink to={"/userportal/books"}>BOOKS</NavLink>
              </li>
              <li>
                <NavLink to={"/userportal/cart"}>CART</NavLink>
              </li>
            <li>
              <NavLink to={"/"}>LOGOUT</NavLink>
            </li>
          </ul>
        </>
      )}
    </div>
  );
};

export default Navbar;
