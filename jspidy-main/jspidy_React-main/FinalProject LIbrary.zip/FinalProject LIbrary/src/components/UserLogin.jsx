import React, { useRef } from 'react'
import { useNavigate } from 'react-router-dom'

const UserLogin = () => {
    let email = useRef();
    let pass = useRef();
    let nav = useNavigate();
    let login = e => {
      e.preventDefault();
      if (
        email.current.value === "user@gmail.com" &&
        pass.current.value === "123"
      ) {
        nav("/userportal");
      } else {
        alert("enter correct credentials");
      }
    };
  return (
    <div>
      <form action="" onSubmit={login}>
        <input type="text" placeholder="enter email" ref={email} />
        <br />
        <br />
        <input type="text" placeholder="enter password" ref={pass} />
        <br />
        <br />
        <br />
        <button>login </button>
      </form>
    </div>
  );
}

export default UserLogin
