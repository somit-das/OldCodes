import React, { useEffect, useState } from 'react'

import { useLocation, useNavigate } from 'react-router-dom'

const Users = () => {
  let [users, setUsers] = useState([])
  useEffect(() =>
  {    
    let api = fetch("http://localhost:4000/users");
     let fullapi=api.then((first) =>
    {
          return first.json()
     })
    fullapi.then((sec) =>
    {
      setUsers(sec)
      console.log(users);
      
    })
   
  }, [users]);
  return (
    <div>
      <h1>all users are here</h1>
      <div className="par">
        {users.map((a) =>
        {
          return (
            <>
              <div className="ch">
                <b>{a.firstName}</b>
                <b>{a.lastName}</b>
                <h4>{a.email}</h4>
              </div>
            </>
          );
        })}
      </div>
    </div>
  )
}

export default Users
