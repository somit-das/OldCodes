import React, { useRef } from 'react'
import { useNavigate } from 'react-router-dom'


const AddBooks = () => {

  let title = useRef()
  let url = useRef()
  let authors = useRef()
  let desc = useRef()
  let nav=useNavigate()
  function f1(e)
  {
    e.preventDefault();

    let newBook = {
      title: title.current.value,
      thumbnailUrl: url.current.value,
      authors: authors.current.value,
      longDescription:desc.current.value
    };
    fetch("http://localhost:4000/books", {
      method: "POST",
      body: JSON.stringify(newBook),
    });
    alert("book added ");

    nav("/adminportal/books");
  }
  
  
  return (
    <div>
      <h2>add books here</h2>
     

      <form action="" onSubmit={f1}>
        
        <input type="text" placeholder='entre book name'  ref={title}/>
        <br /><br />
        <input type="text" placeholder='enter book url'  ref={url}/>
        <br /><br />
        <input type="text" placeholder='enter book authors' ref={authors}/>
        <br /><br />
        <input type="text" placeholder='enter description'  ref={desc}/>
        <br /><br />
        <button>click here to add a book</button>
      </form>
    </div> 
  )
}

export default AddBooks
