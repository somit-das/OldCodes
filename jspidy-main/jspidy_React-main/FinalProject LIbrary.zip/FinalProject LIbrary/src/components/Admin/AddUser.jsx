import React, { useRef } from 'react'
import { useNavigate } from 'react-router-dom';

const AddUser = () => {
  
  let first = useRef();
  let last= useRef();
  let mail = useRef();
  
  let nav = useNavigate()
  function f1(e) {
    e.preventDefault();

    let newUser = {
      firstName: first.current.value,
      lastName: last.current.value,
      email: mail.current.value,
    };
    fetch("http://localhost:4000/users", {
      method: "POST",
      body: JSON.stringify(newUser),
    });
    alert("user added ");

    nav("/adminportal/users");
  }
  
  
  return (
    <div>
      add users HERE
      <form action="" onSubmit={f1}>
        <input type="text" placeholder="entre firts name" ref={first} />
        <br />
        <br />
        <input type="text" placeholder="enter last name" ref={last} />
        <br />
        <br />
        <input type="text" placeholder="enter email" ref={mail} />
        <br />
        <br />
       
        <br />
        <br />
        <button>click here to add a user</button>
      </form>
    </div>
  );
}

export default AddUser
