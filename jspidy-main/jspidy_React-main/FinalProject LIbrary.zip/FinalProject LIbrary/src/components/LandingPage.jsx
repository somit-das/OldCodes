import React, { useState } from 'react'
import AdminLogin from './AdminLogin'
import UserLogin from './UserLogin'


const LandingPage = () => {
    
let [login, setLogin] = useState(true)
    let log = () =>
    {
        setLogin(!login)
    }

    return (
        <>
            <h1>{login?"WELCOME TO ADMINLOGIN":"WELCOME TO USER LOGIN"}</h1>
            <button onClick={log}>{login ? "adminlogin" : "userlogin"}</button> 
            {login?<AdminLogin/>:<UserLogin/>}
        </>
 )
}
export default LandingPage
