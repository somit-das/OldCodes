import React, { useEffect, useState } from "react";
import "./../style/Book.css";
import {  useLocation, useNavigate, useParams } from "react-router-dom";

const ReadBook = () => {
    let para = useParams()
  let nav = useNavigate()
  let loc = useLocation()
  let path=loc.pathname.startsWith("/adminportal")
  let [book, setBook] = useState([]);
  useEffect(() => {
    let api = fetch(`http://localhost:4000/books/${para.id}`);
    let fullapi = api.then(first => {
      return first.json();
    });
    fullapi.then(sec => {
      setBook(sec);
      console.log(book);
    });
  }, [book]);
    
  
  
    //going back
    let gotobook = () =>
    {
      
      if (path)
      {
           nav("/adminportal/books");
      }
      else {
           nav("/userportal/books");
      }
     
    }


    //adding to the cart
    let [cart, setCart] = useState([])
    useEffect(() =>
    {
        let api = fetch("http://localhost:4000/cart");
        let fullapi=api.then((first) =>
        {
             return first.json()
        })
        fullapi.then((sec) =>
        {
            setCart(sec)
            console.log(cart);
            
        })
    }, [cart])
    console.log(cart);

  
  let addcart = (id,image,title,authors) =>
    {
       let cartitem = {
            cartid: id,
            cartimage: image,
            carttitle: title,
            cartauthors:authors
         }
         
        fetch("http://localhost:4000/cart", {
            method: "POST",
            body:JSON.stringify(cartitem)
         });
        alert("book added ")
     
    if (path)
    {
      nav("/adminportal/cart");
    }
    else {
      nav("/userportal/cart");
    }
       
        

    }
  
  


    

  return (
    <div>
      <h3>{book.title}</h3>
      <br />
      <img src={book.thumbnailUrl} alt="" width={300} height={250} />
      <h4>author is {book.authors}</h4>
      <details>
        <summary>click here for the more information</summary>
        <p>{book.longDescription}</p>
      </details>
     
        <button
          onClick={() => {
            addcart(book.id, book.thumbnailUrl, book.title, book.authors);
          }}
        >
          ADD TO CART
        </button>
      
      <button onClick={gotobook}>go back to books</button>
    </div>
  );
};

export default ReadBook;
