
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import LandingPage from './components/LandingPage';
import AdminPortal from './components/Admin/AdminPortal';
import Userportal from './components/User/Userportal';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route element={<LandingPage />} path='/'></Route>
          <Route element={<AdminPortal />} path='/adminportal/*'></Route>
          <Route element={<Userportal/>} path='/userportal/*'></Route>
         
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
